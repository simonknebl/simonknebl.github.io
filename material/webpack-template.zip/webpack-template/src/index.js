import 'normalize.css';
import './style.scss';

function importAll(r) {
    return r.keys().map(r);
}

const database = require('./content.json');
const images = importAll(require.context('./images/', true, /\.(png|jpe?g|gif)$/));