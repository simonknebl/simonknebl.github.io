import 'normalize.css';
import './style.scss';

function importAll(r) {
    return r.keys().map(r);
}

function getJSON(path) {
    return fetch(path).then(response => response.json());
}