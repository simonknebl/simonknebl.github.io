import 'normalize.css';
import './style.scss';

function importAll(r) {
    return r.keys().map(r);
}

// const database = require('inhalt.json');

// const imgs = importAll(require.context('./images/', true, /\.(png|jpe?g)$/));