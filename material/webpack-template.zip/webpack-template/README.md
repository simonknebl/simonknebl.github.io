# Template for Webpack Development

Template Webpack development environment

## Installation

Install npm dependencies

```bash
npm i
```

## Usage

### Development server

```bash
npm start
```

You can view the development server at `localhost:8080`.

### Production build

```bash
npm run build
```